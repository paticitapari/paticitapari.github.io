# Dopetrope
A [Mura CMS](http://www.getmura.com) theme based on the [Dopetrope](http://html5up.net/dopetrope/) responsive site template built on HTML5 and CSS3 from [**HTML5** UP](http://html5up.net/).

## Theme Documentation
Before you get started, please be sure to read the theme's documentation located at http://docs.dopetrope.murathemes.com/.