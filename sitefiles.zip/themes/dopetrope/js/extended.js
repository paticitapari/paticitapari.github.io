/*
	This file is part of the Dopetrope Mura CMS Theme

	Notes:
		- this is where custom overrides to both the original theme and Mura CMS scripts is added
*/
jQuery(document).ready(function($) {

	// add any custom theme js here

});